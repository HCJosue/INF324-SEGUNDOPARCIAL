﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int cR, cG, cB;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mostrar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "archivos jpg|*.jpg";
            openFileDialog1.ShowDialog();
            Bitmap bmp = new Bitmap(openFileDialog1.FileName);
            pictureBox1.Image = bmp;
            pictureBox2.Image = bmp;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals(""))
            {
                MessageBox.Show("Haz click en la imagen por favor");
            }
            else
            {
                OdbcConnection con = new OdbcConnection();
                OdbcCommand cmd = new OdbcCommand();
                con.ConnectionString = "DSN=examen";
                cmd.CommandText = "insert into texturas(descripcion,cR,cG,CB,colorpintar) ";
                cmd.CommandText = cmd.CommandText + "values('" + textBox4.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                mostrar();
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int red =Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
            int green = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
            int blue = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
            String colorp = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[4].Value);
            //pintar(red,green,blue,colorp);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            /*Bitmap bmp = new Bitmap(pictureBox1.Image);
           Color c = new Color();
           c = bmp.GetPixel(e.X, e.Y);
           textBox1.Text = c.R.ToString();
           textBox2.Text = c.G.ToString();
           textBox3.Text = c.B.ToString();
            */
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Color c = new Color();
            int sR, sG, sB;
            sR = 0;
            sG = 0;
            sB = 0;
            for (int i = e.X; i < e.X + 10; i++)
                for (int j = e.Y; j < e.Y + 10; j++)
                {
                    c = bmp.GetPixel(i, j);
                    sR = sR + c.R;
                    sG = sG + c.G;
                    sB = sB + c.B;
                }
            sR = sR / 100;
            sG = sG / 100;
            sB = sB / 100;
            cR = sR;
            cG = sG;
            cB = sB;
            textBox1.Text = sR.ToString();
            textBox2.Text = sG.ToString();
            textBox3.Text = sB.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label11.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label11.BackColor = Color.FromName("White");
            int n = dataGridView1.RowCount-1;
            for (int i=0;i<n;i++) {
                int red = Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value);
                int green = Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
                int blue = Convert.ToInt32(dataGridView1.Rows[i].Cells[3].Value);
                String colorp = Convert.ToString(dataGridView1.Rows[i].Cells[4].Value);
                String objeto = Convert.ToString(dataGridView1.Rows[i].Cells[0].Value);
                pintar(red, green, blue, colorp,objeto);
            }
        }

        public void mostrar() {
            OdbcConnection con = new OdbcConnection();
            OdbcDataAdapter ada = new OdbcDataAdapter();
            con.ConnectionString = "DSN=examen";
            ada.SelectCommand = new OdbcCommand();
            ada.SelectCommand.Connection = con;
            ada.SelectCommand.CommandText = "select * from texturas";
            DataSet ds = new DataSet();
            ada.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        public void pintar(int cR2,int cG2, int cB2,string pintar,String objeto) {
            Bitmap bmp = new Bitmap(pictureBox2.Image);
            Bitmap bmp2 = new Bitmap(bmp.Width, bmp.Height);
            Color c = new Color();
            Color c2 =Color.FromName(pintar);
            int encontrado = 0;
            int sR, sG, sB;
            for (int i = 0; i < bmp.Width - 10; i = i + 10)
                for (int j = 0; j < bmp.Height - 10; j = j + 10)
                {
                    sR = 0; sG = 0; sB = 0;
                    for (int ip = i; ip < i + 10; ip++)
                        for (int jp = j; jp < j + 10; jp++)
                        {
                            c = bmp.GetPixel(ip, jp);
                            sR = sR + c.R;
                            sG = sG + c.G;
                            sB = sB + c.B;
                        }
                    sR = sR / 100;
                    sG = sG / 100;
                    sB = sB / 100;

                    if (((cR2 - 20 <= sR) && (sR <= cR2 + 20)) && ((cG2 - 20 <= sG) && (sG <= cG2 + 20)) && ((cB2 - 20 <= sB) && (sB <= cB2 + 20)))
                    {
                        encontrado++;
                        for (int ip = i; ip < i + 10; ip++)
                            for (int jp = j; jp < j + 10; jp++)
                            {
                                bmp2.SetPixel(ip, jp, c2);
                            }
                    }
                    else
                    {
                        for (int ip = i; ip < i + 10; ip++)
                            for (int jp = j; jp < j + 10; jp++)
                            {
                                c = bmp.GetPixel(ip, jp);
                                bmp2.SetPixel(ip, jp, Color.FromArgb(c.R, c.G, c.B));
                            }
                    }

                }
            pictureBox2.Image = bmp2;
            if (encontrado>0) {
                label11.Text = label11.Text + "\n" + "Encontrados el objeto " + objeto + " lo pintados de color "+pintar;
            }
        }
    }
}
