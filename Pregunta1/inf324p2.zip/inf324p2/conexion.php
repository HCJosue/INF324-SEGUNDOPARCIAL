<?php
$con=mysqli_connect("localhost","usuario2","123456");
mysqli_select_db($con,"workflowp2");
?>