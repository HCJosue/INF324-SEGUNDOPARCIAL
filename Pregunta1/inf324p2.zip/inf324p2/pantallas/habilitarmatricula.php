<?php
    include "seguimiento.php";
    echo "<h2>Proceso 6: Habilitar matricula</h2><br>";
    $ci=$registro2['usuario'];
    $sql="select * from academico.persona a,academico.pagos xp where a.ci=".$ci." and xp.ci=".$ci;
    $buscardatos=mysqli_query($con,$sql);
    $sacardatos=mysqli_fetch_array($buscardatos);
    if($_SESSION["rol"]=="kardex"){
        if($valor==0){
            echo "<h4>Verifique si el estudiante ".$sacardatos["nombre"]." ".$sacardatos["apellido"]." esta habilitado en la tabla de la derecha</h4>";
            ?>
            <div class="form-check">
                <div>
                    <input type="radio" id="huey" name="revisar" value="si" checked />
                    <label for="huey">SI</label>
                </div>

                <div>
                    <input type="radio" id="dewey" name="revisar" value="no" />
                    <label for="dewey">NO</label>
                </div>
            </div>
            <?php
        }
        else{
            $datossi=mysqli_query($con,"select * from seguimiento where ticket=".$ticket." order by proceso DESC");
            $mensaje="no";
            while($sacarsi=mysqli_fetch_array($datossi)){
                if($sacarsi["proceso"]=="P7"){
                    $mensaje="si";
                }
            }
            echo "<h4 class='hecho'>Usted coloco ".$mensaje." al verificar del codigo CPT ".$sacardatos['cpt']."</h4>";
        }
    }
    else{
        if($valor==0){
            echo "<h4 class='hecho'>Kardex esta en revision si usted esta habilitado en el sistema</h4>";
        }
        else{
            echo "<h4 class='hecho'>Su caso ya ha sido revisado presione 'completar proceso' para ver el resultado</h4>";
        }
    }
?>