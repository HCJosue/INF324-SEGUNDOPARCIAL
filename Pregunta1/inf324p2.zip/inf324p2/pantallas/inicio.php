<?php
    echo "<h2>Proceso 1: Inicio</h2><br>";
    include "seguimiento.php";
    if($valor==0){
        echo "<h4 class='text-info'>Para iniciar presiona el boton 'Completar proceso'</h4>";
    }
    else{
        echo "<h4 class='hecho'>Ya completo este proceso</h4>";
    }
?>