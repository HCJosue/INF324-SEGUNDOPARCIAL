<?php
    echo "<h2>Proceso 4: Pagar matricula</h2><br>";
    include "seguimiento.php";
    if(isset($_GET["error"])){
        echo "<h3><p class='text-danger'>La cuenta seleccionada no tiene fondos suficiente para el pago</p></h3>";
    }
    $cuenta=mysqli_query($con,"select * from academico.cuenta where ci=".$_SESSION["ci"]);
    if($valor==0){   
?> 
    <h4>Pagar con la cuenta: <select class="form-select" aria-label="Default select example" name="cuenta">
                            <?php
                                while($datoscuenta=mysqli_fetch_array($cuenta)){
                                    echo "<option>".$datoscuenta['nro']."</option>";
                                }
                            ?>
                            </select></h4>
<?php }
else{
    $cuenta=mysqli_query($con,"select * from academico.pagos where ci=".$_SESSION["ci"]);
    $datoscuenta=mysqli_fetch_array($cuenta);
    echo "<h4 class='hecho'>Ya pagaste la matricula con la cuenta ".$datoscuenta['cpt']."</h4>";
}?>
