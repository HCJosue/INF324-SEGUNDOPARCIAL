<?php
    session_start();
    include("conexion.php");
    $resultado2=mysqli_query($con,"select * from academico.persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    include("cabecera.php");
    $sacar=mysqli_query($con,"select * from seguimiento where (proceso like 'P5' or proceso like 'P6') and fechafin is NULL");
?>
    <div class="container w-75 bg-primary mt-5 rounded shadow py-2">
        <h3 class="text-center text-white">Procesos para revisar</h3>
        <table class="table table-light border border-light">
        <thead>
            <tr class="thead table-warning border border-dark text-dark">
            <th scope="col">Ticket</th>
            <th scope="col">Flujo</th>
            <th scope="col">Proceso</th>
            <th scope="col">Fecha inicio</th>
            <th scope="col">Completar operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $r='<i class="fa-solid fa-hourglass-end fa-2xl" style="color: #ff0000;"></i>';
                while($fila=mysqli_fetch_array($sacar)){
                  echo "<tr><td>".$fila['ticket']."</td>";
                  echo "<td>".$fila['flujo']."</td>";
                  echo "<td>".$fila['proceso']."</td>";
                  echo "<td>".$fila['fechaini']."</td>";
                  echo "<td><a href='principal.php?ticket=".$fila['ticket']."&flujo=".$fila['flujo']."&procesoactual=".$fila['proceso']."'>$r</a></td></tr>";
                }
            ?>
        </tbody>
        </table>
    </div>
<?php
    include("pie.php");
?>