<?php
    session_start();
    include "conexion.php";
    $resultado=mysqli_query($con,"SELECT max(ticket) max from seguimiento");
    $fila=mysqli_fetch_array($resultado);
    if(!isset($fila["max"])){
        $fecha=date('Y-m-d h:i:s');
        $ci=$_SESSION["ci"];
        $resultado2=mysqli_query($con,"insert into seguimiento values(1,'F1','P1','$fecha',NULL,$ci)");
        header("location: ".$_SESSION["rol"].".php");
    }
    else{
        $fecha=date('Y-m-d h:i:s');
        $ci=$_SESSION["ci"];
        $resultado2=mysqli_query($con,"insert into seguimiento values(".($fila['max']+1).",'F1','P1','$fecha',NULL,$ci)");
        header("location: ".$_SESSION["rol"].".php");
    }
?>