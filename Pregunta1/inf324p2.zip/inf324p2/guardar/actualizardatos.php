<?php
    session_start();
    $nombre=$_GET["nombre"];
    $apellido=$_GET["apellido"];
    if($valor==0){
        if($nombre!="" && $apellido!=""){
            $sql="update academico.persona set nombre='".$nombre."', apellido='".$apellido."' where CI=".$_SESSION["ci"];
            mysqli_query($con,$sql);
        }
    }
?>