<?php
    if($valor==0){
        $montoc=mysqli_query($con,"select * from academico.cuenta where nro=".$_GET["cuenta"]);
        $monto=mysqli_fetch_array($montoc);
        if($monto["monto"]>=27){
            mysqli_query($con,"update academico.pagos set pagado=1, cuenta=".$_GET["cuenta"]." where ci=".$_SESSION["ci"]." and ctp=".$_SESSION["ticket"]);
            mysqli_query($con,"update academico.cuenta set monto=monto-27 where nro=".$_GET["cuenta"]);
        }
        else{
            mysqli_query($con,"update academico.pagos set cuenta=".$_GET["cuenta"]." where ci=".$_SESSION["ci"]); 
        }
    }
?>